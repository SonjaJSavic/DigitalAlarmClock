#include <AT89C51RC2.h>
#include <intrins.h>
#include <stdio.h>
#include <stdlib.h>
#define LCD_D7 P1_0
#define LCD_D6 P1_1
#define LCD_D5 P1_2
#define LCD_D4 P1_3
#define LCD_BL P1_4
#define LCD_EN P3_2
#define LCD_RS P3_3

bit prekidT0;

char sekunda;
char min;
char sati;

char alarmS;
char alarmM;
char alarmSati;

char trenutno_vreme[9];
char alarm_vreme[9];

bit alarm;
bit snuz;

char* poruka;

char mod;
int prosla_sekunda;
char prosla_minuta;
int debounce;
unsigned char taster;

char izbor = 1;
char izbor1 = 0;
char izbor2 = 0;

void delay(){

	int i, j;

	for(i = 0; i <= 20; i++){

		for(j = 0;j <= 10; j++){
		
		
		}

	}
}

/*void delaymikro(void){

	int i;
	for(i = 0; i < 100; i++){
	
	}	

}*/

void inicijalizacija() {

	//frekvencija oscilatora 11.0592
	// 11.0592 / 12 = 0.9216
	//1 / 0.9216 = 1.085 - duzina trajanja masinskog ciklusa
	//timer se podesava na 250 : x*1.085 = 250 -> x = 230 masinskih ciklusa 
	//256 - 230 = 26	
	
	
	ET0 = 1; 		//dozvola prekida tajmera0
	TMOD = 2;		//GATE0 = 0(bit3), C/T0 = 0(bit 2), mod2(bit 0- 1)
	TH0 = 26;		//vrednost za prvo brojanje tajmera
	TL0 = 26;		//vrednost za prvo brojanje tajmera
	TR0 = 1;	    //dozvola rada tajmera0
	EA = 1;	 	    //globalna dozvola prekida

	//serijska komunikacija inicijalizacija
	//baud rate u Flip3.4.7 i u Parallax Seriall Terminal podesiti na 9600 zbog inicijalizacije
	
	BRL=220;
	PCON|=0x80;
	SCON=0x50;
	BDRCON|=0x1E;
	BDRCON|=0xFC;
	ES=1;
	REN = 1;

	//inicijalizacija promenljivih koje se koriste
	sekunda=0;
	min=0;
	sati=0;
	alarmS=5;
	alarmM=0;
	alarmSati=0;
	poruka="Rise and shine!";
	mod=0;
	prosla_sekunda=0;
	prosla_minuta=0;
	debounce=0;
	taster=0;

}

//prekid tajmera 0
void tajmerT0(void) interrupt 1{

	prekidT0=1;


}


//prekid serijske komunikacije

void serijska(void) interrupt 4{


	if(RI == 1){
	
		RI = 0;
	
	}

	if(TI == 1){
		  
		poruka++;

		if(*poruka != '\0'){
			
			SBUF = *(poruka);
		}

		TI = 0;
	}
}

//SA VEZBI

void posalji_komandu(bit b4, bit b3, bit b2, bit b1){

	LCD_RS=0;
	LCD_EN=1;
	LCD_D7=b4;
	LCD_D6=b3;
	LCD_D5=b2;
	LCD_D4=b1;
	LCD_EN=0;
	delay();
}

void init_disp(){

	posalji_komandu(0,0,1,1);
	posalji_komandu(0,0,1,1);
	posalji_komandu(1,1,0,0);
	delay();
	posalji_komandu(0,0,1,0);
	posalji_komandu(0,0,1,0);
	posalji_komandu(1,1,0,0);
	delay();
	posalji_komandu(0,0,0,0);
	posalji_komandu(1,1,1,1);
	delay();
	posalji_komandu(0,0,0,0);
	posalji_komandu(0,0,0,1);
	delay();
	posalji_komandu(0,0,0,0);
	posalji_komandu(0,1,1,0);
			
}

void ispisi_karakter(char karakter){

	LCD_RS = 1;
	LCD_EN = 1;
	
	LCD_D7 = (karakter&0x80)>>7;
	LCD_D6 = (karakter&0x40)>>6;
	LCD_D5 = (karakter&0x20)>>5;
	LCD_D4 = (karakter&0x10)>>4;
	
	LCD_EN = 0;	
	_nop_();
	LCD_EN = 1;

    LCD_D7 = (karakter&0x08)>>3;
	LCD_D6 = (karakter&0x04)>>2;
	LCD_D5 = (karakter&0x02)>>1;
	LCD_D4 = (karakter&0x01);
	LCD_EN = 0;
}


void novi_red(){

	posalji_komandu(1,1,0,0);
	posalji_komandu(0,0,0,0);
	
}

void cisti_displej(){

	posalji_komandu(0,0,0,0);
	posalji_komandu(0,0,0,1);
	
}

void ispisi_string(char* str){
	int i = 0;
	
	while (str[i] != '\0') {

		ispisi_karakter(str[i]);
		i++;

		if(i == 9){
		
		 	novi_red();

		 }
	}

}

//konverzija trenutnog vreme i vremena alarma u string

void vreme_u_string(){


	char sati1;
	char minute1;
	char sekunde1;
	char baza;
	char ostatak;
	sati1 = sati;
	minute1 = min;
	sekunde1 = sekunda;
	baza = 10;
	trenutno_vreme[2] = ':';
	trenutno_vreme[5] = ':';
	trenutno_vreme[8] = '\0';

	//primer : broj = 23 
	//23 celobrojno sa 10(bazom) daje 2, a ostatak je 3. 3+48 u ascii tabeli je karakter 3
	// sada uzimamo to 2 koje smo dobili celobrojnim deljenjem, isto ga delimo sa bazom, ostatak je 2, 2+48 u ascii tabeli je karakter 2
	//pri ispisu prvo treba da ispisemo poslednju cifru koju smo dobili

   	//sati
	ostatak = sati1%baza;
	trenutno_vreme[1] = ostatak + 48;
	sati1 = sati1 / baza;
	ostatak = sati1%baza;
	trenutno_vreme[0] = ostatak + 48;

   	//minute
	ostatak = minute1%baza;
	trenutno_vreme[4] = ostatak + 48;
	minute1 = minute1 / baza;
	ostatak = minute1%baza;
	trenutno_vreme[3] = ostatak + 48;
	
	//sekunde
	ostatak = sekunde1%baza;
	trenutno_vreme[7] = ostatak + 48;
	sekunde1 = sekunde1 / baza;
	ostatak = sekunde1%baza;
	trenutno_vreme[6] = ostatak + 48;
}

void alarm_u_string(){
	
	//princip je isti kao i u prethodnoj funkciji

	char alarm_sekunde1;
	char alarm_minute1;
	char alarm_sati1;
	char baza;
	char ostatak;
	alarm_sekunde1 = alarmS;
	alarm_minute1 = alarmM;
	alarm_sati1 = alarmSati;
	baza = 10;

	alarm_vreme[2] = ':';
	alarm_vreme[5] = ':';
	alarm_vreme[8] = '\0';
	
	//sati
	ostatak = alarm_sati1%baza;
	alarm_vreme[1] = ostatak + 48;
	alarm_sati1 = alarm_sati1 / baza;
	ostatak = alarm_sati1%baza;
	alarm_vreme[0] = ostatak + 48;

   	//minute
	ostatak = alarm_minute1%baza;
	alarm_vreme[4] = ostatak + 48;
	alarm_minute1 = alarm_minute1 / baza;
	ostatak = alarm_minute1%baza;
	alarm_vreme[3] = ostatak + 48;
	
	//sekunde
	ostatak = alarm_sekunde1%baza;
	alarm_vreme[7] = ostatak + 48;
	alarm_sekunde1 = alarm_sekunde1 / baza;
	ostatak = alarm_sekunde1%baza;
	alarm_vreme[6] = ostatak + 48;

}


//odbrojavanje trenutnog vremena

void broj_vreme(){

	if(++sekunda==60){

		sekunda=0;

		if(++min==60){

			min=0;

			if(++sati==24){

				sati=0;
			}
		}
	}
	vreme_u_string();
}


void setuj_alarm(bit p){

	if(p){
	
		alarm = 1;
	
	}else{
	
		alarm = 0;
	
	}

}
//provera da li je doslo do alarma i setovanje alarm promenljive ukoliko jeste
void proveri_alarm(){

	bit provera;

	if(sekunda == alarmS && min == alarmM && sati == alarmSati){
	
		provera = 1;
	
	}else{
	
		provera = 0;
	
	}

	setuj_alarm(provera);

} 


//podesavanje trenutnog vremena i vremena alarma tasterima


void setuj_vreme(){


bit promena=0;
bit i;
bit i1;
bit i2;


   //tasteri P0_3, P0_4 i P0_5 sluze da se izabere da li ce se menjati sati(P0_3), minute(P0_4) ili sekunde(P0_5)

	if(P0_3==0 || P0_4==0 || P0_5==0 ){

		debounce++;

		if(P0_3==0){

			taster=1;

		}

		if(P0_4==0){

			taster=2;

		}
		if(P0_5==0){

			taster=3;

		}
	
	}
				

   //taster P0_0 ukoliko se pritisne dodaje se 10 umesto 1, na izabranu velicinu
   //mora prvo da se pritisne P0_0 pa onda taster za izabranu velicinu
   //ako ste dodali 10, pa zelite opet da dodate 10, taster se mora pritisnuti ponovo

	if(P0_0 == 0 ){

		 i=1;
		 P2_0 = 0;
		   
		if(i==1 && P2_0 == 0 ){

		    izbor = 10;
			i=0;

		}else{

			izbor = 1;
		}
	}

	//taster P0_1 ukoliko se pritisne, menja se vrednosti trenutnog vremena
   //ukoliko zelite da menjate vrednost trenutnog vremena morate pritisnuti taster P0_1, a zatim izabrati da li zelite da menjate sate, minute ili sekunde
   //ukoliko zelite ponovo da menjate neku od vrednosti trenutnog vremena, taster P0_1 se mora ponovo pritisnuti

	if(P0_1 == 0 ){

		 i1=1;
		 P2_1 = 0;
		   
		if(i1==1 && P2_1 == 0 ){

		    izbor1 = 1;
			i1=0;

		}else{

			izbor1 = 0;
		}
	}

	//taster P0_2 ukoliko se pritisne, menja se vrednosti alarma
   //ukoliko zelite da menjate vrednost alarma morate pritisnuti taster P0_2, a zatim izabrati da li zelite da menjate sate, minute ili sekunde
   //ukoliko zelite ponovo da menjate neku od vrednosti alarma, taster P0_2 se mora ponovo pritisnuti

	if(P0_2 == 0 ){

		 i2=1;
		 P2_2 = 0;
		   
		if(i2==1 && P2_2 == 0 ){

		    izbor2 = 1;
			i2=0;

		}else{

			izbor2 = 0;
		}
	}


  //ovde se vrsi gore navedena logika, prvo se proverava debounce, tj da li je taster bio pritisnut(20) ili drzan(1s), i zatim se pustio(vrednost mu se vrati na 1)
  //u zavisnosti od toga koji je taster pritisnut menjaju se sati, minuti i sekunde

	if(debounce>20 && debounce<=4000 ){

		switch(taster){
			
			case 1:
				if(P0_3 == 1 ){
					debounce = 0;
					promena=1;
					if(izbor1 == 1 && izbor == 10 && izbor2 == 0){
					
						sati += 10;
						if(sati>=24)

							sati-=24;

					
					}
					 if(izbor1 == 1 && izbor == 1 && izbor2 == 0){
					
						sati += 1;

						if(sati>=24)

							sati=0;	
					
					}
					if(izbor2 == 1 && izbor == 10 && izbor1 == 0){
					
						alarmSati += 10;
						if(alarmSati>=24)

							alarmSati-=24;
					
					}
					if(izbor2 == 1 && izbor == 1 && izbor1 == 0){
					
						alarmSati += 1;
						if(alarmSati>=24)

							alarmSati=0;

				}
				}
				break;
			case 2:
				if(P0_4 == 1){
					debounce = 0;
					promena=1;
				
					if(izbor1 == 1 && izbor == 10 && izbor2 == 0){
					
						min += 10;
						if(min>=60)

							min-=60;

					
					}
					 if(izbor1 == 1 && izbor == 1 && izbor2 == 0){
					
						min += 1;

						if(min>=60)

							min=0;	
					
					}
					if(izbor2 == 1 && izbor == 10 && izbor1 == 0){
					
						alarmM += 10;
						if(alarmM>=60)

							alarmM-=60;
					
					}
					if(izbor2 == 1 && izbor == 1 && izbor1 == 0){
					
						alarmM += 1;
						if(alarmM>=60)

							alarmM=0;

				}
				}
				break;

			case 3:
				if(P0_5 == 1){
					debounce = 0;
					promena=1;
					if(izbor1 == 1 && izbor == 10 && izbor2 == 0){
					
						sekunda += 10;
						if(sekunda>=60)

							sekunda-=60;

					
					}
					 if(izbor1 == 1 && izbor == 1 && izbor2 == 0){
					
						sekunda += 1;

						if(sekunda>=24)

							sekunda=0;	
					
					}
					if(izbor2 == 1 && izbor == 10 && izbor1 == 0){
					
						alarmS += 10;
						if(alarmS>=60)

							alarmS-=60;
					
					}
					if(izbor2 == 1 && izbor == 1 && izbor1 == 0){
					
						alarmS += 1;
						if(alarmS>=60)

							alarmS=0;

				}
				}
				break;
	}
	}

	//doslo je do promene neke od vrednosti(sati, minuti, sekunde), i to znaci da novo vreme ili alarm treba da se ispisu na displej

	if(promena == 1){
		
		vreme_u_string();
		alarm_u_string();
		cisti_displej();
		ispisi_string(trenutno_vreme);
		novi_red();
		ispisi_string(alarm_vreme);
		
		//vracanje starih vrednosti promenljivih koje se koriste za izbor trenutnog vremena, alarma, i da li se dodaje 10 ili 1
		 
		P2_0 = 1;
		P2_1 = 1;
		izbor = 1; 
		izbor1 = 0; 
		izbor2 = 0;
		P2_2 = 1;
		}	
 }
 
//snooze -  povecavanje vremena alarma za 1 minutu

void potvrdi_alarm(){

	alarmSati = 0;
	alarmS = 0;
	alarmM = 0;

	alarm_u_string();

}  

/*void setuj_snuz(bit p){

	if(p){
	
		snuz = 1;
	
	}else{
	
		snuz = 0;
	
	}

}

void provera(){

	
   	bit provera;

	if(sekunda == alarmS && min == alarmM && sati == alarmSati){
	
		provera = 1;
	
	}else{
	
		provera = 0;
	
	}

	setuj_snuz(provera);


} */


void main(void){

	char doslo_do_alarma;
	char tasterPritisnut;
	bit promena;
	char alarm1;
	bit flag;
	


	char i;
	i=0;
	doslo_do_alarma=0;
	tasterPritisnut=0;

	inicijalizacija();
	vreme_u_string();
	alarm_u_string();
	init_disp();


	while(1){
		//da li je doslo do prekida tajmera
		if(prekidT0){

			prekidT0=0;

			if(promena){

				//provera da li je pritisnut taster P0_7
				//P0_7 taster sluzi da izbor rada casovnika
				//ukoliko je taster pritisnut prelazi se u mod podesavanja vremena i alarma, a ukoliko nije normalno radi
				if(P0_7==0){

					tasterPritisnut++;

					if(tasterPritisnut==20){

						tasterPritisnut=0;
						promena=0;

						if((mod++)==1)
							mod=0;
					}	
				}else{

					tasterPritisnut=0;
				}
			}

			if(P0_7==1){

				promena=1;
			}
			//normalan rad
			if(mod==0){

				prosla_sekunda++;

				if(prosla_sekunda==3942){

					prosla_sekunda=0;
					broj_vreme();
					proveri_alarm();
					cisti_displej();

					if(alarm || alarm1){
						prosla_minuta++;

						if(doslo_do_alarma==0){
							//ispisuje se poruka na displeju i salje se poruka serijskom komunikacijom
							poruka="Rise and shine!";
							ispisi_string(" Alarm!");
							
							if(flag == 1)
								alarm1 = 0;
						  	
							else 
						   		alarm1 = 1;
							doslo_do_alarma++;
							SBUF=poruka[0];	

						}else{
							
							ispisi_string(trenutno_vreme);

							if((doslo_do_alarma++)==2)

								doslo_do_alarma=0;
						}
		
					
					}else{
						ispisi_string(trenutno_vreme);
					}
					novi_red();
					ispisi_string(alarm_vreme);
				}

				if(alarm1==1 && P0_6 == 0){
					debounce++;
				}
				if(debounce > 20 && P0_6 == 1){
					debounce = 0;
					flag = 1;
					potvrdi_alarm();
					alarm1 = 0;
				}
				

				
			}else{
				//podesavanje vremena i alarma
				setuj_vreme();
			}
		}
	}
}